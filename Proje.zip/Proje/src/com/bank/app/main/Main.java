package com.bank.app.main;

import com.bank.app.accounts.BankaHesabi;
import com.bank.app.accounts.VadesizHesap;
import com.bank.app.accounts.YatirimHesabi;
import com.bank.app.cards.KrediKarti;
import com.bank.app.people.BankaPersoneli;
import com.bank.app.people.Musteri;
import com.bank.app.service.BankaService;

public class Main {
    public static void main(String[] args) {

        BankaService bankaService = new BankaService();

        // --- Banka Personeli Oluşturma ---
        BankaPersoneli personel = new BankaPersoneli("Ayşe", "Kaya", "98765432100", "Müşteri Temsilcisi");
        System.out.println("Personel ID: " + personel.getPersonelID());
        System.out.println("Unvan: " + personel.getUnvan());
        System.out.println("---------------------------");

        // --- 1. Müşteri Oluşturma ---
        Musteri musteri1 = new Musteri("Ahmet", "Yılmaz", "12345678901");
        bankaService.musteriOlustur(musteri1);
        System.out.println("Müşteri No: " + musteri1.getMusteriNumarasi());
        System.out.println("---------------------------");

        // Personel müşteriyi kendi listesine ekler
        personel.musteriEkle(musteri1);

        // --- 2. Müşteri Adına Hesap Açma ---
        bankaService.hesapAc(musteri1, "vadesiz");
        bankaService.hesapAc(musteri1, "yatirim");
        System.out.println("Toplam hesap sayısı: " + musteri1.getHesaplar().size());
        System.out.println("---------------------------");

        // Hesaplara erişim
        VadesizHesap vadesizHesap = (VadesizHesap) musteri1.getHesaplar().get(0);
        YatirimHesabi yatirimHesabi = (YatirimHesabi) musteri1.getHesaplar().get(1);

        System.out.println("Vadesiz IBAN: " + vadesizHesap.getIban());
        System.out.println("Yatırım IBAN: " + yatirimHesabi.getIban());
        System.out.println("---------------------------");

        // --- 3. Hesaba Para Yatırma ---
        bankaService.paraYatir(vadesizHesap, 8000);
        bankaService.yatirimYap(yatirimHesabi, 3000);
        System.out.println("---------------------------");

        // --- 4. Hesaplar Arası Para Transferi ---
        // Vadesiz hesaptan yatırım hesabına 2000 TL transfer
        bankaService.transferYap(vadesizHesap, yatirimHesabi, 2000);
        System.out.println("Vadesiz bakiye: " + vadesizHesap.getBakiye());
        System.out.println("Yatırım bakiye: " + yatirimHesabi.getBakiye());
        System.out.println("---------------------------");

        // --- 5. Müşteriye Kredi Kartı Tanımlama ---
        bankaService.krediKartiAta(musteri1);
        System.out.println("Toplam kart sayısı: " + musteri1.getKrediKartlari().size());

        KrediKarti kart = musteri1.getKrediKartlari().get(0);
        System.out.println("Kart Numarası: " + kart.getKartNumarasi());
        System.out.println("Kart Limiti: " + kart.getLimit());

        // Karta borç yükle
        kart.setGuncelBorc(2500);
        System.out.println("Güncel Borç: " + kart.getGuncelBorc());
        System.out.println("---------------------------");

        // --- 6. Kredi Kartı Borcu Ödeme ---
        bankaService.borcOde(vadesizHesap, kart, 1500);
        System.out.println("Ödeme sonrası vadesiz bakiye: " + vadesizHesap.getBakiye());
        System.out.println("Ödeme sonrası kart borcu: " + kart.getGuncelBorc());
        System.out.println("---------------------------");

        // --- 7. Hesap Silme İşlemi ---
        // Bakiyesi olan hesap silinmeye çalışılır (uyarı vermeli)
        System.out.println("Bakiyeli hesabı silme denemesi:");
        bankaService.hesapSil(musteri1, yatirimHesabi);

        // Yatırım hesabı sıfırlanıp tekrar denenirse silinir
        yatirimHesabi.setBakiye(0);
        System.out.println("Bakiye sıfırlandıktan sonra silme:");
        bankaService.hesapSil(musteri1, yatirimHesabi);
        System.out.println("Kalan hesap sayısı: " + musteri1.getHesaplar().size());
    }
}
