package com.bank.app.cards;

import java.util.Random;

// Kredi kartı bilgilerini tutan sınıf
public class KrediKarti {

    private String kartNumarasi;
    private double limit;
    private double guncelBorc;

    // Varsayılan constructor: kart numarası otomatik üretilir, limit 10000, borç sıfır
    public KrediKarti() {
        this.kartNumarasi = olusturKartNumarasi();
        this.limit = 10000.0;
        this.guncelBorc = 0.0;
    }

    // Özel limitli kart oluşturmak için parametreli constructor
    public KrediKarti(double limit) {
        this.kartNumarasi = olusturKartNumarasi();
        this.limit = limit;
        this.guncelBorc = 0.0;
    }

    // 4 ile başlayan 16 haneli rastgele kart numarası üretir
    private String olusturKartNumarasi() {
        long sayi = Math.abs(new Random().nextLong()) % 1000000000000000L;
        return String.format("4%015d", sayi);
    }

    // --- Get ve Set Metotları ---

    public String getKartNumarasi() { return kartNumarasi; }
    public void setKartNumarasi(String kartNumarasi) { this.kartNumarasi = kartNumarasi; }

    public double getLimit() { return limit; }
    public void setLimit(double limit) { this.limit = limit; }

    public double getGuncelBorc() { return guncelBorc; }
    public void setGuncelBorc(double guncelBorc) { this.guncelBorc = guncelBorc; }
}
