package com.bank.app.people;

// Banka personeli ve müşterilerin ortak özelliklerini tutan temel sınıf
public class Kisi {

    private String ad;
    private String soyad;
    private String tcKimlikNo;

    // Varsayılan constructor
    public Kisi() {
    }

    // Parametreli constructor
    public Kisi(String ad, String soyad, String tcKimlikNo) {
        this.ad = ad;
        this.soyad = soyad;
        this.tcKimlikNo = tcKimlikNo;
    }

    // --- Get ve Set Metotları ---

    public String getAd() { return ad; }
    public void setAd(String ad) { this.ad = ad; }

    public String getSoyad() { return soyad; }
    public void setSoyad(String soyad) { this.soyad = soyad; }

    public String getTcKimlikNo() { return tcKimlikNo; }
    public void setTcKimlikNo(String tcKimlikNo) { this.tcKimlikNo = tcKimlikNo; }
}
