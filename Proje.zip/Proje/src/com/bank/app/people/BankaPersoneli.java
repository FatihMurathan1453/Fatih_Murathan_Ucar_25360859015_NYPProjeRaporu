package com.bank.app.people;

import java.util.ArrayList;
import java.util.Random;

// Banka personeline ait bilgileri tutan sınıf
// Kisi sınıfından miras almaktadır
public class BankaPersoneli extends Kisi {

    private String personelID;
    private String unvan;
    private ArrayList<Musteri> musteriler; // Personelin sorumlu olduğu müşteriler

    // Varsayılan constructor
    public BankaPersoneli() {
        super();
        this.personelID = olusturPersonelID();
        this.musteriler = new ArrayList<>();
    }

    // Parametreli constructor
    public BankaPersoneli(String ad, String soyad, String tcKimlikNo, String unvan) {
        super(ad, soyad, tcKimlikNo);
        this.personelID = olusturPersonelID();
        this.unvan = unvan;
        this.musteriler = new ArrayList<>();
    }

    // P harfi + 6 haneli rastgele sayı ile personel ID üretir
    private String olusturPersonelID() {
        return "P" + (100000 + new Random().nextInt(900000));
    }

    // Sorumlu müşteri listesine müşteri ekler
    public void musteriEkle(Musteri musteri) {
        musteriler.add(musteri);
    }

    // Sorumlu müşteri listesinden müşteri çıkarır
    public void musteriSil(Musteri musteri) {
        musteriler.remove(musteri);
    }

    // --- Get ve Set Metotları ---

    public String getPersonelID() { return personelID; }
    public void setPersonelID(String personelID) { this.personelID = personelID; }

    public String getUnvan() { return unvan; }
    public void setUnvan(String unvan) { this.unvan = unvan; }

    public ArrayList<Musteri> getMusteriler() { return musteriler; }
    public void setMusteriler(ArrayList<Musteri> musteriler) { this.musteriler = musteriler; }
}
