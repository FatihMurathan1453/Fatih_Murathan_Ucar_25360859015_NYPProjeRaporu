package com.bank.app.people;

import com.bank.app.accounts.BankaHesabi;
import com.bank.app.accounts.VadesizHesap;
import com.bank.app.accounts.YatirimHesabi;
import com.bank.app.cards.KrediKarti;

import java.util.ArrayList;
import java.util.Random;

// Müşteri bilgilerini ve işlemlerini yöneten sınıf
// Kisi sınıfından miras almaktadır
public class Musteri extends Kisi {

    private String musteriNumarasi;
    private ArrayList<BankaHesabi> hesaplar;
    private ArrayList<KrediKarti> krediKartlari;

    // Varsayılan constructor
    public Musteri() {
        super();
        this.musteriNumarasi = olusturMusteriNumarasi();
        this.hesaplar = new ArrayList<>();
        this.krediKartlari = new ArrayList<>();
    }

    // Parametreli constructor
    public Musteri(String ad, String soyad, String tcKimlikNo) {
        super(ad, soyad, tcKimlikNo);
        this.musteriNumarasi = olusturMusteriNumarasi();
        this.hesaplar = new ArrayList<>();
        this.krediKartlari = new ArrayList<>();
    }

    // M harfi + 6 haneli rastgele sayı ile müşteri numarası üretir
    private String olusturMusteriNumarasi() {
        return "M" + (100000 + new Random().nextInt(900000));
    }

    // Parametre olarak gelen hesap türüne göre yeni hesap oluşturur ve listeye ekler
    public void hesapEkle(String hesapTuru) {
        if ("vadesiz".equalsIgnoreCase(hesapTuru)) {
            hesaplar.add(new VadesizHesap());
        } else if ("yatirim".equalsIgnoreCase(hesapTuru)) {
            hesaplar.add(new YatirimHesabi());
        } else {
            System.out.println("Geçersiz hesap türü: " + hesapTuru);
        }
    }

    // Yeni bir kredi kartı oluşturur ve listeye ekler
    public void krediKartiEkle() {
        krediKartlari.add(new KrediKarti());
    }

    // Hesap silme: önce bakiye kontrolü yapılır
    public void hesapSil(BankaHesabi hesap) {
        if (hesap.getBakiye() > 0) {
            System.out.println("Lütfen öncelikle bakiyenizi başka bir hesaba aktarınız.");
        } else {
            hesaplar.remove(hesap);
            System.out.println("Hesap başarıyla silindi.");
        }
    }

    // Kredi kartı silme: önce borç kontrolü yapılır
    public void krediKartiSil(KrediKarti kart) {
        if (kart.getGuncelBorc() == 0) {
            krediKartlari.remove(kart);
            System.out.println("Kredi kartı başarıyla silindi.");
        } else {
            System.out.println("Lütfen öncelikle borç ödemesi yapınız.");
        }
    }

    // --- Get ve Set Metotları ---

    public String getMusteriNumarasi() { return musteriNumarasi; }
    public void setMusteriNumarasi(String musteriNumarasi) { this.musteriNumarasi = musteriNumarasi; }

    public ArrayList<BankaHesabi> getHesaplar() { return hesaplar; }
    public void setHesaplar(ArrayList<BankaHesabi> hesaplar) { this.hesaplar = hesaplar; }

    public ArrayList<KrediKarti> getKrediKartlari() { return krediKartlari; }
    public void setKrediKartlari(ArrayList<KrediKarti> krediKartlari) { this.krediKartlari = krediKartlari; }
}
