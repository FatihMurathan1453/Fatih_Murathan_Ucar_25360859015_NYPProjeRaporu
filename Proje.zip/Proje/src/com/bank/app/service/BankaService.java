package com.bank.app.service;

import com.bank.app.accounts.BankaHesabi;
import com.bank.app.accounts.VadesizHesap;
import com.bank.app.accounts.YatirimHesabi;
import com.bank.app.cards.KrediKarti;
import com.bank.app.people.Musteri;

// Banka iş mantığını yöneten servis sınıfı
// Tüm işlemler bu sınıf üzerinden gerçekleştirilmektedir
public class BankaService {

    // Yeni müşteri kaydı oluşturur
    public void musteriOlustur(Musteri musteri) {
        System.out.println("Müşteri oluşturuldu: " + musteri.getAd() + " " + musteri.getSoyad());
    }

    // Müşteri adına hesap açar (vadesiz veya yatırım)
    public void hesapAc(Musteri musteri, String hesapTuru) {
        musteri.hesapEkle(hesapTuru);
        System.out.println(hesapTuru + " hesabı açıldı.");
    }

    // Belirtilen hesaba para yatırır
    public void paraYatir(BankaHesabi hesap, double miktar) {
        hesap.setBakiye(hesap.getBakiye() + miktar);
        System.out.println(miktar + " TL hesaba yatırıldı. Yeni bakiye: " + hesap.getBakiye());
    }

    // Yatırım hesabına para ekler
    public void yatirimYap(YatirimHesabi hesap, double miktar) {
        hesap.paraEkle(miktar);
    }

    // Vadesiz hesaptan başka bir hesaba para transferi gerçekleştirir
    public void transferYap(VadesizHesap kaynak, BankaHesabi hedef, double miktar) {
        kaynak.paraTransferi(hedef, miktar);
    }

    // Müşteriye yeni bir kredi kartı tanımlar
    public void krediKartiAta(Musteri musteri) {
        musteri.krediKartiEkle();
        System.out.println("Kredi kartı tanımlandı.");
    }

    // Vadesiz hesaptan kredi kartı borcunu öder
    public void borcOde(VadesizHesap hesap, KrediKarti kart, double miktar) {
        hesap.krediKartiBorcOdeme(kart, miktar);
    }

    // Müşterinin hesabını siler (bakiye kontrolü Musteri sınıfında yapılır)
    public void hesapSil(Musteri musteri, BankaHesabi hesap) {
        musteri.hesapSil(hesap);
    }
}
