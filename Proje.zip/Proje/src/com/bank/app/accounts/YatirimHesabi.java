package com.bank.app.accounts;

// Yatırım hesabı işlemlerini gerçekleştiren sınıf
// BankaHesabi sınıfından miras almaktadır
public class YatirimHesabi extends BankaHesabi {

    // Varsayılan constructor
    public YatirimHesabi() {
        super();
    }

    // Başlangıç bakiyesiyle hesap açmak için parametreli constructor
    public YatirimHesabi(double bakiye) {
        super(bakiye);
    }

    // Hesaba para ekler
    public void paraEkle(double miktar) {
        setBakiye(getBakiye() + miktar);
        System.out.println(miktar + " TL yatırım hesabına eklendi.");
    }

    // Hesaptan para çeker
    public void paraCek(double miktar) {
        setBakiye(getBakiye() - miktar);
        System.out.println(miktar + " TL yatırım hesabından çekildi.");
    }
}
