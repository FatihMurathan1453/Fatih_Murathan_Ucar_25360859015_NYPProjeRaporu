package com.bank.app.accounts;

import com.bank.app.cards.KrediKarti;

// Vadesiz hesap işlemlerini gerçekleştiren sınıf
// BankaHesabi sınıfından miras almaktadır
public class VadesizHesap extends BankaHesabi {

    // Varsayılan constructor
    public VadesizHesap() {
        super();
    }

    // Başlangıç bakiyesiyle hesap açmak için parametreli constructor
    public VadesizHesap(double bakiye) {
        super(bakiye);
    }

    // Hesaplar arası para transferi: gönderen hesaptan düşer, alıcı hesaba ekler
    public void paraTransferi(BankaHesabi aliciHesap, double miktar) {
        setBakiye(getBakiye() - miktar);
        aliciHesap.setBakiye(aliciHesap.getBakiye() + miktar);
        System.out.println(miktar + " TL transfer gerçekleştirildi.");
    }

    // Kredi kartı borç ödeme: hesaptan miktar düşülür, kartın borcu azaltılır
    public void krediKartiBorcOdeme(KrediKarti kart, double miktar) {
        setBakiye(getBakiye() - miktar);
        kart.setGuncelBorc(kart.getGuncelBorc() - miktar);
        System.out.println(miktar + " TL borç ödemesi yapıldı.");
    }
}
